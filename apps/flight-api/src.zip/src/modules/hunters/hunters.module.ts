import { Module } from '@nestjs/common';
import { HuntersController } from './hunters.controller';
import { HuntersService } from './hunters.service';

@Module({
  controllers: [HuntersController],
  providers: [HuntersService]
})
export class HuntersModule {}
