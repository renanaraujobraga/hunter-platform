import { Body, Controller, Get, Param, Post } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Hunter } from '@prisma/client';
import { CreateHunterDto } from './dto/create-hunter.dto';
import { HuntersService } from './hunters.service';

@ApiTags('Hunters')
@Controller('hunters')
export class HuntersController {
  constructor(private readonly huntersService: HuntersService) {}

  @Get()
  list(): Promise<Hunter[]> {
    return this.huntersService.list();
  }

  @Get(':id')
  findById(@Param('id') id: string): Promise<Hunter> {
    return this.huntersService.findById(id);
  }

  @Post()
  create(@Body() dto: CreateHunterDto): Promise<Hunter> {
    return this.huntersService.create(dto);
  }
}
