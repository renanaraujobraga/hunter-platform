import { Injectable, NotFoundException } from '@nestjs/common';
import { Hunter } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';
import { CreateHunterDto } from './dto/create-hunter.dto';

@Injectable()
export class HuntersService {
  constructor(private readonly prisma: PrismaService) {}

  list(): Promise<Hunter[]> {
    return this.prisma.hunter.findMany({ orderBy: { createdAt: 'desc' } });
  }

  async findById(id: string): Promise<Hunter> {
    const hunter = await this.prisma.hunter.findUnique({ where: { id } });
    if (!hunter) throw new NotFoundException('Hunter nÃ£o encontrado.');
    return hunter;
  }

  async create(dto: CreateHunterDto): Promise<Hunter> {
    const user = await this.prisma.user.findFirst();
    if (!user) throw new NotFoundException('UsuÃ¡rio base nÃ£o encontrado.');

    return this.prisma.hunter.create({
      data: {
        ...dto,
        origin: dto.origin.toUpperCase(),
        destination: dto.destination.toUpperCase(),
        departureFrom: new Date(dto.departureFrom),
        departureTo: new Date(dto.departureTo),
        userId: user.id
      }
    });
  }
}
