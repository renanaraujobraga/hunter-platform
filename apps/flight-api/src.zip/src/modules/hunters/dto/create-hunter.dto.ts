import { ApiProperty, ApiPropertyOptional } from '@nestjs/swagger';
import { IsDateString, IsNumber, IsOptional, IsString, Length, Min } from 'class-validator';

export class CreateHunterDto {
  @ApiProperty({ example: 'Florianópolis → Fortaleza' })
  @IsString()
  name!: string;

  @ApiProperty({ example: 'FLN' })
  @IsString()
  @Length(3, 3)
  origin!: string;

  @ApiProperty({ example: 'FOR' })
  @IsString()
  @Length(3, 3)
  destination!: string;

  @ApiProperty()
  @IsDateString()
  departureFrom!: string;

  @ApiProperty()
  @IsDateString()
  departureTo!: string;

  @ApiPropertyOptional()
  @IsOptional()
  @IsNumber()
  @Min(0)
  maxPrice?: number;
}
