import { Injectable, UnauthorizedException } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { JwtService, JwtSignOptions } from '@nestjs/jwt';
import { compare } from 'bcryptjs';
import { PrismaService } from '../../prisma/prisma.service';
import { LoginDto } from './dto/login.dto';

@Injectable()
export class AuthService {
  constructor(
    private readonly prisma: PrismaService,
    private readonly jwt: JwtService,
    private readonly config: ConfigService
  ) {}

  async login(dto: LoginDto): Promise<{ accessToken: string }> {
    const user = await this.prisma.user.findUnique({ where: { email: dto.email } });

    if (!user || !(await compare(dto.password, user.passwordHash))) {
      throw new UnauthorizedException('Credenciais inválidas.');
    }

    const expiresIn = this.config.get<string>('JWT_EXPIRES_IN') ?? '1d';
    const options: JwtSignOptions = { expiresIn: expiresIn as JwtSignOptions['expiresIn'] };

    return {
      accessToken: await this.jwt.signAsync(
        { sub: user.id, email: user.email, role: user.role },
        options
      )
    };
  }
}
