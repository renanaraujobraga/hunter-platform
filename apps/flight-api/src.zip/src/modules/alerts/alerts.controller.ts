import { Controller, Get, Param, Patch } from '@nestjs/common';
import { ApiTags } from '@nestjs/swagger';
import { Alert } from '@prisma/client';
import { AlertsService } from './alerts.service';

@ApiTags('Alerts')
@Controller('alerts')
export class AlertsController {
  constructor(private readonly alertsService: AlertsService) {}

  @Get()
  list(): Promise<Alert[]> {
    return this.alertsService.list();
  }

  @Patch(':id/read')
  markAsRead(@Param('id') id: string): Promise<Alert> {
    return this.alertsService.markAsRead(id);
  }
}
