import { Injectable, NotFoundException } from '@nestjs/common';
import { Alert } from '@prisma/client';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class AlertsService {
  constructor(private readonly prisma: PrismaService) {}

  list(): Promise<Alert[]> {
    return this.prisma.alert.findMany({
      orderBy: { createdAt: 'desc' },
      include: { hunter: true }
    });
  }

  async markAsRead(id: string): Promise<Alert> {
    const alert = await this.prisma.alert.findUnique({ where: { id } });
    if (!alert) throw new NotFoundException('Alerta nÃ£o encontrado.');

    return this.prisma.alert.update({
      where: { id },
      data: { isRead: true }
    });
  }
}
