import { Injectable } from '@nestjs/common';
import { PrismaService } from '../../prisma/prisma.service';

@Injectable()
export class DashboardService {
  constructor(private readonly prisma: PrismaService) {}

  async getSummary() {
    const [hunters, unreadAlerts, pricesAnalyzed, feed] = await Promise.all([
      this.prisma.hunter.findMany({
        where: { status: 'ACTIVE' },
        orderBy: { updatedAt: 'desc' },
        take: 3
      }),
      this.prisma.alert.count({ where: { isRead: false } }),
      this.prisma.priceRecord.count(),
      this.prisma.alert.findMany({ orderBy: { createdAt: 'desc' }, take: 3 })
    ]);

    const estimatedSavings = hunters.reduce<number>(
      (total, hunter) =>
        total + Math.max(0, (hunter.previousPrice ?? 0) - (hunter.currentPrice ?? 0)),
      0
    );

    return {
      metrics: {
        estimatedSavings,
        activeHunters: hunters.length,
        pricesAnalyzed,
        criticalAlerts: unreadAlerts
      },
      hunters,
      intelligenceFeed: feed
    };
  }
}
